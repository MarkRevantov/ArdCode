// 24 March 2019 - 18:26
#ifndef STEPPER_h
#define STEPPER_h

class STEPPER
  {
  private:
    byte stepPins[3] = {};    //EN, DIR, PUL

    long int startTime = 0;
    int myStep = 0;
    int8_t micStep = 1;
    int8_t mode = 1;
    int32_t stepTime = 0;
    
            
  public:
    STEPPER (byte pins[3]);
    void attach (int8_t _mode, float speed);             
    bool move (long int stepsNum);  
    bool drive ();
    void changeSpeed (float speed);
  };
#endif
