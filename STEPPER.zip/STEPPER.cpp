///////////

#if ARDUINO >= 100
  #include <Arduino.h>
#else
  #include <WProgram.h>
#endif

#include "STEPPER.h"


STEPPER::STEPPER (byte pins[3])
  {
  for (byte i = 0; i < 3; i++) stepPins[i] = pins[i];
  }

void STEPPER::attach (int8_t _mode, float speed)
  {
  mode = _mode;
  if (mode < 1) mode = 1;
  else if (mode > 32) mode = 32;

  for (byte i = 0; i < 3; i++) pinMode(stepPins[i], OUTPUT);

  changeSpeed (speed);
  
  myStep = -100;
  }

void STEPPER::changeSpeed (float speed)
  {
  if (speed < 0) digitalWrite (stepPins[1], LOW);
  else digitalWrite (stepPins[1], HIGH);
  
  stepTime = (int32_t) floor ((float)1e+6/(abs(speed)*mode));
  }
  
bool STEPPER::move (long int stepsNum)
  {
  if (myStep == -100) 
    {
    startTime = micros();
    myStep = 0;
    }

  if (drive ()) myStep++;

  if (myStep >= stepsNum*mode) return true;
  return false;
  }

bool STEPPER::drive ()
  {
  if (micros() - startTime >= stepTime)
    {
    startTime = micros ();
  
    digitalWrite (stepPins[0], LOW);
    digitalWrite (stepPins[2], HIGH);
    digitalWrite (stepPins[2], LOW);

    return true;
    }
  return false;
  }
